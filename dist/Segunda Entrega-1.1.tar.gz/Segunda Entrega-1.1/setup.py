from setuptools import setup

setup(
    name="Segunda Entrega",
    version="1.1",
    description="Registro de usuarios con listado de productos, ergo, carrito",
    author="Franco Mancebo",
    author_email="francoqui2212@gmail.com",
    packages=["Python"]
)